/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author goyar
 */
public class HospitalTest {

    public void testRegisterPatient() {

        Hospital hospital = new Hospital();

        Patient patient = new Patient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            PatientCategory.OUTPATIENT
        );

        assertTrue(hospital.registerPatient(patient));
        assertEquals(1, hospital.getTotalPatients());
    }

    public void testSearchPatient() {

        Hospital hospital = new Hospital();

        Patient patient = new Patient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        Patient result = hospital.searchPatient("P001");

        assertNotNull(result);
        assertEquals("John", result.getFirstName());
    }

    public void testDuplicatePatientId() {

        Hospital hospital = new Hospital();

        Patient patient1 = new Patient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            PatientCategory.OUTPATIENT
        );

        Patient patient2 = new Patient(
            "P001",
            "Peter",
            "Jones",
            30,
            "Male",
            "Cold",
            PatientCategory.OUTPATIENT
        );

        assertTrue(hospital.registerPatient(patient1));
        assertFalse(hospital.registerPatient(patient2));
    }

    public void testUpdatePatient() {

        Hospital hospital = new Hospital();

        Patient patient = new Patient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        assertTrue(
            hospital.updatePatient(
                "P001",
                "James",
                "Smith",
                26,
                "Male",
                "Cold"
            )
        );

        assertEquals(
            "James",
            hospital.searchPatient("P001").getFirstName()
        );
    }

    public void testDeletePatient() {

        Hospital hospital = new Hospital();

        Patient patient = new Patient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        assertTrue(hospital.deletePatient("P001"));
        assertNull(hospital.searchPatient("P001"));
    }

    public void testAllocateBed() {

        Hospital hospital = new Hospital();

        Inpatient patient = new Inpatient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            "Ward 1",
            "Not Allocated"
        );

        hospital.registerPatient(patient);

        assertTrue(hospital.allocateBed("P001"));
        assertEquals(1, hospital.getOccupiedBeds());
    }

    public void testReleaseBed() {

        Hospital hospital = new Hospital();

        Inpatient patient = new Inpatient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            "Ward 1",
            "Not Allocated"
        );

        hospital.registerPatient(patient);

        hospital.allocateBed("P001");

        assertTrue(hospital.releaseBed("P001"));
        assertEquals(0, hospital.getOccupiedBeds());
    }

    public void testOutpatientCannotGetBed() {

        Hospital hospital = new Hospital();

        Patient patient = new Patient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        assertFalse(hospital.allocateBed("P001"));
    }

    public void testCannotAllocateOccupiedBed() {

        Hospital hospital = new Hospital();

        Inpatient patient1 = new Inpatient(
            "P001",
            "John",
            "Smith",
            25,
            "Male",
            "Flu",
            "Ward 1",
            "Not Allocated"
        );

        Inpatient patient2 = new Inpatient(
            "P002",
            "Peter",
            "Jones",
            30,
            "Male",
            "Cold",
            "Ward 1",
            "Not Allocated"
        );

        hospital.registerPatient(patient1);
        hospital.registerPatient(patient2);

        assertTrue(hospital.allocateBed("P001"));
        assertTrue(hospital.allocateBed("P002"));

        assertEquals(2, hospital.getOccupiedBeds());
    }

    public void testTwentyBeds() {

        Hospital hospital = new Hospital();

        assertEquals(20, hospital.getAvailableBeds());
    }

    private void assertTrue(boolean registerPatient) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int i, int totalPatients) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertNotNull(Patient result) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(String john, String firstName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(boolean registerPatient) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertNull(Patient searchPatient) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
