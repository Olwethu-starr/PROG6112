/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author goyar
 */

import java.util.ArrayList;
import java.util.Comparator;

public class Hospital {

    private ArrayList<Patient> patients;
    private ArrayList<Bed> beds;

    public Hospital() {

        patients = new ArrayList<>();
        beds = new ArrayList<>();

        // Create 20 beds
        for (int i = 1; i <= 20; i++) {

            String bedNumber;

            if (i < 10) {
                bedNumber = "B0" + i;
            } else {
                bedNumber = "B" + i;
            }

            beds.add(new Bed(bedNumber));
        }
    }

    // ---------------- PATIENT MANAGEMENT ----------------

    public boolean registerPatient(Patient patient) {

        if (searchPatient(patient.getPatientId()) != null) {
            return false;
        }

        patients.add(patient);
        return true;
    }

    public Patient searchPatient(String patientId) {

        for (Patient patient : patients) {

            if (patient.getPatientId().equalsIgnoreCase(patientId)) {
                return patient;
            }
        }

        return null;
    }

    public boolean deletePatient(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        // Release bed if patient is occupying one
        for (Bed bed : beds) {

            if (bed.getPatient() == patient) {
                bed.release();
            }
        }

        patients.remove(patient);

        return true;
    }

    public boolean updatePatient(String patientId,
                                 String firstName,
                                 String lastName,
                                 int age,
                                 String gender,
                                 String medicalCondition) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        patient.setFirstName(firstName);
        patient.setLastName(lastName);
        patient.setAge(age);
        patient.setGender(gender);
        patient.setMedicalCondition(medicalCondition);

        return true;
    }

    public void displayAllPatients() {

        if (patients.isEmpty()) {
            System.out.println("No patients registered.");
            return;
        }

        for (Patient patient : patients) {

            System.out.println("-------------------------");
            patient.displayDetails();
        }
    }

    // ---------------- BED MANAGEMENT ----------------

    public boolean allocateBed(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        // Only inpatients may have beds
        if (patient.getCategory() != PatientCategory.INPATIENT) {
            return false;
        }

        // Check if patient already has a bed
        for (Bed bed : beds) {

            if (bed.getPatient() == patient) {
                return false;
            }
        }

        // Find available bed
        for (Bed bed : beds) {

            if (!bed.isOccupied()) {

                bed.allocate(patient);

                if (patient instanceof Inpatient) {

                    Inpatient inpatient = (Inpatient) patient;

                    inpatient.setBedNumber(bed.getBedNumber());
                    inpatient.setWardNumber("Ward 1");
                }

                return true;
            }
        }

        return false;
    }

    public boolean releaseBed(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        for (Bed bed : beds) {

            if (bed.getPatient() == patient) {

                bed.release();

                if (patient instanceof Inpatient) {

                    Inpatient inpatient = (Inpatient) patient;

                    inpatient.setBedNumber("Not Allocated");
                }

                return true;
            }
        }

        return false;
    }

    public void displayWard() {

        System.out.println("\nWARD LAYOUT");
        System.out.println("-------------------------");

        for (int i = 0; i < beds.size(); i++) {

            beds.get(i).displayBed();

            if ((i + 1) % 5 == 0) {
                System.out.println();
            }
        }
    }

    public void displayAvailableBeds() {

        System.out.println("\nAVAILABLE BEDS");
        System.out.println("-------------------------");

        boolean found = false;

        for (Bed bed : beds) {

            if (!bed.isOccupied()) {

                System.out.println(bed.getBedNumber());
                found = true;
            }
        }

        if (!found) {
            System.out.println("No available beds.");
        }
    }

    public void displayOccupiedBeds() {

        System.out.println("\nOCCUPIED BEDS");
        System.out.println("-------------------------");

        boolean found = false;

        for (Bed bed : beds) {

            if (bed.isOccupied()) {

                System.out.println(
                    bed.getBedNumber()
                    + " - "
                    + bed.getPatient().getFirstName()
                    + " "
                    + bed.getPatient().getLastName()
                );

                found = true;
            }
        }

        if (!found) {
            System.out.println("No occupied beds.");
        }
    }

    // ---------------- REPORTS ----------------

    public int getTotalPatients() {
        return patients.size();
    }

    public int getOccupiedBeds() {

        int count = 0;

        for (Bed bed : beds) {

            if (bed.isOccupied()) {
                count++;
            }
        }

        return count;
    }

    public int getAvailableBeds() {
        return 20 - getOccupiedBeds();
    }

    public double getOccupancyPercentage() {

        return (getOccupiedBeds() / 20.0) * 100;
    }

    // ---------------- SORTING ----------------

    public void sortBySurname() {

        patients.sort(
            Comparator.comparing(
                Patient::getLastName,
                String.CASE_INSENSITIVE_ORDER
            )
        );
    }

    public void sortByPatientId() {

        patients.sort(
            Comparator.comparing(
                Patient::getPatientId,
                String.CASE_INSENSITIVE_ORDER
            )
        );
    }
}
