/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

/**
 *
 * @author goyar
 */

import java.util.Scanner;

public class Main {

    static Scanner input = new Scanner(System.in);
    static Hospital hospital = new Hospital();

    public static void main(String[] args) {

        int choice;

        do {

            displayMenu();

            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1:
                    registerPatient();
                    break;

                case 2:
                    searchPatient();
                    break;

                case 3:
                    updatePatient();
                    break;

                case 4:
                    deletePatient();
                    break;

                case 5:
                    hospital.displayAllPatients();
                    break;

                case 6:
                    allocateBed();
                    break;

                case 7:
                    releaseBed();
                    break;

                case 8:
                    hospital.displayWard();
                    break;

                case 9:
                    hospital.displayAvailableBeds();
                    break;

                case 10:
                    hospital.displayOccupiedBeds();
                    break;

                case 11:
                    displayReports();
                    break;

                case 12:
                    hospital.sortBySurname();
                    System.out.println("Patients sorted by surname.");
                    break;

                case 13:
                    hospital.sortByPatientId();
                    System.out.println("Patients sorted by Patient ID.");
                    break;

                case 0:
                    System.out.println("Exiting system...");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);
    }

    public static void displayMenu() {

        System.out.println("\n=================================");
        System.out.println("   MEDICARE HOSPITAL SYSTEM");
        System.out.println("=================================");
        System.out.println("1. Register Patient");
        System.out.println("2. Search Patient");
        System.out.println("3. Update Patient");
        System.out.println("4. Delete Patient");
        System.out.println("5. Display All Patients");
        System.out.println("6. Allocate Bed");
        System.out.println("7. Release Bed");
        System.out.println("8. Display Ward Layout");
        System.out.println("9. Display Available Beds");
        System.out.println("10. Display Occupied Beds");
        System.out.println("11. Display Reports");
        System.out.println("12. Sort by Surname");
        System.out.println("13. Sort by Patient ID");
        System.out.println("0. Exit");
        System.out.println("=================================");
    }

    // ---------------- REGISTER ----------------

    public static void registerPatient() {

        System.out.println("\nREGISTER PATIENT");

        System.out.print("Patient ID: ");
        String id = input.nextLine();

        if (hospital.searchPatient(id) != null) {

            System.out.println("Patient ID already exists.");
            return;
        }

        System.out.print("First Name: ");
        String firstName = input.nextLine();

        System.out.print("Last Name: ");
        String lastName = input.nextLine();

        System.out.print("Age: ");
        int age = input.nextInt();
        input.nextLine();

        System.out.print("Gender: ");
        String gender = input.nextLine();

        System.out.print("Medical Condition: ");
        String condition = input.nextLine();

        System.out.println("\nPatient Category:");
        System.out.println("1. Inpatient");
        System.out.println("2. Outpatient");
        System.out.println("3. Emergency");

        System.out.print("Choose category: ");
        int category = input.nextInt();
        input.nextLine();

        Patient patient;

        switch (category) {

            case 1 -> patient = new Inpatient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    "Ward 1",
                    "Not Allocated"
                );

            case 2 -> patient = new Patient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    PatientCategory.OUTPATIENT
                );

            case 3 -> patient = new Patient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    PatientCategory.EMERGENCY
                );

            default -> {
                System.out.println("Invalid category.");
                return;
            }
        }

        if (hospital.registerPatient(patient)) {

            System.out.println("Patient registered successfully.");

        } else {

            System.out.println("Patient could not be registered.");
        }
    }

    // ---------------- SEARCH ----------------

    public static void searchPatient() {

        System.out.print("Enter Patient ID: ");
        String id = input.nextLine();

        Patient patient = hospital.searchPatient(id);

        if (patient == null) {

            System.out.println("Patient not found.");

        } else {

            System.out.println("\nPATIENT FOUND");
            System.out.println("-------------------------");

            patient.displayDetails();
        }
    }

    // ---------------- UPDATE ----------------

    public static void updatePatient() {

        System.out.print("Enter Patient ID: ");
        String id = input.nextLine();

        Patient patient = hospital.searchPatient(id);

        if (patient == null) {

            System.out.println("Patient not found.");
            return;
        }

        System.out.print("New First Name: ");
        String firstName = input.nextLine();

        System.out.print("New Last Name: ");
        String lastName = input.nextLine();

        System.out.print("New Age: ");
        int age = input.nextInt();
        input.nextLine();

        System.out.print("New Gender: ");
        String gender = input.nextLine();

        System.out.print("New Medical Condition: ");
        String condition = input.nextLine();

        if (hospital.updatePatient(
                id,
                firstName,
                lastName,
                age,
                gender,
                condition)) {

            System.out.println("Patient updated successfully.");

        } else {

            System.out.println("Patient could not be updated.");
        }
    }

    // ---------------- DELETE ----------------

    public static void deletePatient() {

        System.out.print("Enter Patient ID: ");
        String id = input.nextLine();

        if (hospital.deletePatient(id)) {

            System.out.println("Patient deleted successfully.");

        } else {

            System.out.println("Patient not found.");
        }
    }

    // ---------------- ALLOCATE BED ----------------

    public static void allocateBed() {

        System.out.print("Enter Inpatient ID: ");
        String id = input.nextLine();

        if (hospital.allocateBed(id)) {

            System.out.println("Bed allocated successfully.");

        } else {

            System.out.println(
                "Bed could not be allocated."
            );
        }
    }

    // ---------------- RELEASE BED ----------------

    public static void releaseBed() {

        System.out.print("Enter Patient ID: ");
        String id = input.nextLine();

        if (hospital.releaseBed(id)) {

            System.out.println("Bed released successfully.");

        } else {

            System.out.println(
                "Bed could not be released."
            );
        }
    }

    // ---------------- REPORTS ----------------

    public static void displayReports() {

        System.out.println("\n=================================");
        System.out.println("             REPORTS");
        System.out.println("=================================");

        System.out.println(
            "Total Registered Patients: "
            + hospital.getTotalPatients()
        );

        System.out.println(
            "Available Beds: "
            + hospital.getAvailableBeds()
        );

        System.out.println(
            "Occupied Beds: "
            + hospital.getOccupiedBeds()
        );

        System.out.println(
            "Ward Occupancy: "
            + hospital.getOccupancyPercentage()
            + "%"
        );

        System.out.println("=================================");
    }
}
