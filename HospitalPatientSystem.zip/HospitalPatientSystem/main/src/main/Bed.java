/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author goyar
 */
public class Bed {

    private String bedNumber;
    private boolean occupied;
    private Patient patient;

    public Bed(String bedNumber) {
        this.bedNumber = bedNumber;
        this.occupied = false;
        this.patient = null;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public Patient getPatient() {
        return patient;
    }

    public void allocate(Patient patient) {

        this.patient = patient;
        this.occupied = true;
    }

    public void release() {

        this.patient = null;
        this.occupied = false;
    }

    public void displayBed() {

        if (occupied) {
            System.out.println(
                bedNumber + " - OCCUPIED by "
                + patient.getFirstName() + " "
                + patient.getLastName()
            );
        } else {
            System.out.println(bedNumber + " - AVAILABLE");
        }
    }
}